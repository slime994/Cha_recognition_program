import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;


//
//	文字画像の左辺の直線度を特徴量として計算するクラス
//
class  FeatureHeightWidthRatio implements FeatureEvaluater
{
	// 左辺の長さと文字の高さ
	protected float  char_width;
	protected float  char_height;
	protected int up_line;
	protected int down_line;
	protected int left_line;
	protected int right_line;

	// 左or右側の辺（画像の各行の最も左側にあるドットのＸ座標、行にひとつもドットがなければ -1）
	protected int  left_x[];
	protected int  right_x[];

	// 最後に特徴量計算を行った画像（描画用）
	protected BufferedImage  last_image;


	// 特徴量の名前を返す
	public String  getFeatureName()
	{
		return  "文字の縦横比（縦/横）";
	}

	// 文字画像から１次元の特徴量を計算する
	public float  evaluate( BufferedImage image )
	{
		int  height = image.getHeight();
		int  width = image.getWidth();
		int  color2=-1;
		// 左側の辺を取り出す（各行の最も左側のドットのＸ座標を調べる）
		left_x = new int[ height ];
		for ( int y=0; y<height; y++ )
		{
			// 最初は行に黒ピクセルが１つもないものとして -1 で初期化
			left_x[ y ] = -1;

			// 左側から順番にピクセルを走査
			for ( int x=0; x<width; x++ )
			{
				// ピクセルの色を取得
				int  color = image.getRGB( x, y );
				if(x>0) {
					 color2 = image.getRGB(x-1, y);
				}
				// ピクセルの色が黒であれば最も左側のドットとして座標を記録
				if ( color == 0xff000000 && color2== 0xff000000)
				{

						left_x[ y ] = x;
						break;

				}
			}
		}
		// 右側の辺を取り出す（各行の最も右側のドットのＸ座標を調べる）
		right_x = new int[ height ];
		for ( int y=0; y<height; y++ )
		{
			// 最初は行に黒ピクセルが１つもないものとして -1 で初期化
			right_x[ y ] = -1;

			// 左側から順番にピクセルを走査
			for ( int x=0; x<width; x++ )
			{
				// ピクセルの色を取得
				int  color = image.getRGB( x, y );

				// 末端まで捜査、最後に出てきた黒を記録
				if ( color == 0xff000000 )
				{
					right_x[ y ] = x;
				}
			}
		}

		// 文字の高さを計算=a
		char_height = 1.0f;
		int flag_up=0;
		for (int i=0 ; i<height-1 ; i++) {
			if (left_x[i]!=-1) {

				//上を記録
				if (flag_up==0){
					if(left_x[i+3]!=-1) {
						up_line=i;
						flag_up=-1;
					}
				}

				//char_height += 1;
				if(i>4 && left_x[i-3]!=-1)
				down_line = i;
			}
		}
		char_height=down_line-up_line;
		//文字の幅を計算=b
		char_width = 1.0f;
		/*for (int i=0 ; i<height-1 ; i++) {
			float tmp_char_width = right_x[i]-left_x[i];
			if (char_width<tmp_char_width){
				char_width = tmp_char_width;
				left_line = left_x[i];
				right_line = right_x[i];
			}
		}*/
		float maxR = 0;
		for (int i=0 ; i<height-1 ; i++) {
			if (right_x[i]>maxR){
				if(i+4<height && right_x[i+3]!=-1)
				{
					maxR=right_x[i];
					right_line = right_x[i];

				}
				else  if(i>height-5){
					maxR=right_x[i];
					right_line = right_x[i];
				}
			}
		}
		float minL = 500;
		for (int i=0 ; i<height-1 ; i++) {
			if (left_x[i]<minL && left_x[i]!=-1){
				if(i+4<height && left_x[i+3]!=-1) {
					minL=left_x[i];
					left_line = left_x[i];
				}
				else if(i>height-5){
					minL=left_x[i];
					left_line = left_x[i];
				}
			}
		}
		char_width = maxR-minL;

		// 文字の高さ / 幅 の比を計算
		float  ratio;
		ratio = char_height / char_width;

		// 画像を記録（描画用）
		last_image = image;

		return  ratio;
	}

	// 最後に行った特徴量計算の結果を描画する
	public void  paintImageFeature( Graphics g )
	{
		if ( last_image == null )
			return;

		int  ox = 0, oy = 0;
		g.drawImage( last_image, ox, oy, null );

		g.setColor( Color.RED );
		g.drawLine( ox, oy + up_line, ox + last_image.getWidth(), oy + up_line );
		g.drawLine( ox, oy + down_line, ox + last_image.getWidth(), oy + down_line );
		g.drawLine( ox + left_line, oy, ox + left_line, oy + last_image.getHeight());
		g.drawLine( ox + right_line, oy, ox + right_line, oy + last_image.getHeight());

		String  message;
		g.setColor( Color.RED );
		message = "文字の高さ: " + char_height;
		g.drawString( message, ox, oy + 16 );
		message = "文字の幅: " + char_width;
		g.drawString( message, ox, oy + 32 );
		message = "特徴量(文字の高さ / 左辺の長さ): " + char_height / char_width;
		g.drawString( message, ox, oy + 48 );
	}
}
