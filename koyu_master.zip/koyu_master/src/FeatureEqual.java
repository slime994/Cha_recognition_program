import java.awt.Graphics;
import java.awt.image.BufferedImage;

//
//  文字画像の左辺の直線度を特徴量として計算するクラス
//
class  FeatureEqual implements FeatureEvaluater
{
	// 右辺の長さと文字の高さと右から6等分左
	protected float  right_length;
	protected float  left_length;
	protected float  char_height;
	protected float  char_width;
	protected float  equal_left;

	// 右側の辺（画像の各行の最も右側にあるドットのＸ座標、行にひとつもドットがなければ -1）
	//protected int  right_x[];
	//protected int  left_x[];

	// 最後に特徴量計算を行った画像（描画用）
	protected BufferedImage  last_image;


	// 特徴量の名前を返す
	public String  getFeatureName()
	{
		return  "右から一定数左の高さ";
	}

	// 文字画像から１次元の特徴量を計算する
	public float  evaluate( BufferedImage image )
	{
		int  height = image.getHeight();
		int  width = image.getWidth();

		// 右側の辺を取り出す（各行の最も右側のドットのＸ座標を調べる）
		//right_x = new int[ height ];
		right_length = 0;
		for ( int x=width; x>1; x-- )
		{
			// 最初は行に黒ピクセルが１つもないものとして -1 で初期化
			//right_x[ y ] = -1;

			// 右側から順番にピクセルを走査
			for ( int y=0; y<height; y++ )
			{
				// ピクセルの色を取得
				int  color = image.getRGB( x, y );

				// ピクセルの色が黒であれば最も右側のドットとして座標を記録
				if ( color == 0xff000000 && right_length == 0)
				{
					right_length = x;
					break;

				}
			}
		}

                // 左側の辺を取り出す（各行の最も左側のドットのＸ座標を調べる）
		//left_x = new int[ height ];
		left_length = 0;
		for ( int x=0; x<width; x++ )
		{
			// 最初は行に黒ピクセルが１つもないものとして -1 で初期化
			//left_x[ y ] = -1;

			// 左側から順番にピクセルを走査
			for ( int y=0; y<height; y++ )
			{
				// ピクセルの色を取得
				int  color = image.getRGB( x, y );

				// ピクセルの色が黒であれば最も左側のドットとして座標を記録
				if ( color == 0xff000000 && left_length == 0 )
				{
					left_length = x;
					break;
				}
			}
		}







	// 文字の長さを求める
        char_width = right_length - left_length;
	//最も右から文字の長さの6等分左のx座標を求める
	equal_left = left_length - (char_width/6);


		// 文字の高さを計算
		 //// 使用する変数を定義
        int top_y    = -1;     // 最も上のピクセル -1で初期化
        int bottom_y = -1;  // 最も下のピクセル -1で初期化
        //// 最も下(y最大)のピクセルのy座標を求める
        ////// 上からピクセルを走査
        for(int y=0; y<height; y++)
        {
            // 左からピクセルを走査
           int x = (int)equal_left;
                // ピクセルの色を取得
                int color = image.getRGB(x,y);
                // 黒だったらbottom_yにy座標を代入
				if ( color == 0xff000000 )
                {
                    bottom_y = y;

                }

        }
        //// 最も上(y最小)のピクセルのy座標を求める
        for(int y=height-1; y>1 ; y--)
        {
            // 左からピクセルを走査
           int x = (int)equal_left;
                // ピクセルの色を取得
                int color = image.getRGB(x,y);
                // 黒だったらtop_yに値を代入
				if ( color == 0xff000000 )
                {
                    top_y = y;
                }

        }
        // 文字の高さを求める
        char_height = bottom_y - top_y;

/*
		// 文字の左側の辺の長さを計算
        // 左側の長さを求める
        //// 使用する変数の定義
        float left_length_width = 0.0f;    // 三角形の底辺の長さ
        float hypotenuse = 0.0f;          // 三角形の斜辺の長さ
        float sum = 0.0f;

        //// top_yからbottom_yまでの長さを計算
        int count = 0;
        for(int y=top_y; y<bottom_y+1; y++){
            left_length_width = left_x[y-1]-left_x[y];
            hypotenuse        = (float)Math.sqrt(left_length_width * left_length_width + 1.0);
            if(left_length_width < 3 && left_length_width > -3) {
            	// yの時の左辺の長さの合計を計算
            	sum += hypotenuse;
            }
            count++;
        }
        if(sum < char_height) {
        	sum = char_height;
        }
        left_length = sum;

		// 文字の高さ / 左側の辺の長さ の比を計算
		float  left_linearity;
		left_linearity = char_height / left_length;
*/

		// 画像を記録（描画用）
		last_image = image;

		return  char_height;
	}

	// 最後に行った特徴量計算の結果を描画する
	public void  paintImageFeature( Graphics g )
	{
/*		if ( last_image == null )
			return;

		int  ox = 0, oy = 0;
		g.drawImage( last_image, ox, oy, null );

		int  x0, y0, x1, y1;
		for ( int y=0; y<left_x.length-1; y++ )
		{
			y0 = y;
			y1 = y+1;
			x0 = left_x[ y0 ];
			x1 = left_x[ y1 ];
			if ( ( x0 != -1 ) && ( x1 != -1 ) )
			{
				// 左側の辺のピクセルを描画
				g.setColor( Color.RED );
				g.drawLine( ox + x0, oy + y0, ox + x1, oy + y1 );
			}
		}

		String  message;
		g.setColor( Color.RED );
		message = "左辺の長さ: " + left_length;
		g.drawString( message, ox, oy + 16 );
		message = "文字の高さ: " + char_height;
		g.drawString( message, ox, oy + 32 );
		message = "特徴量(文字の高さ / 左辺の長さ): " + char_height / left_length;
		g.drawString( message, ox, oy + 48 );
		*/
	}
}