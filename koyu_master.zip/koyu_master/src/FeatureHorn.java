﻿import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

//
//	一画目の角から終点までの直線の傾きを特徴量として計算するクラス
//
class  FeatureHorn implements FeatureEvaluater
{
	//文字の頂点のy座標
	protected int  upper_y;

	//文字の地上のy座標
	protected int  lower_y;

	//文字の中心のy座標
	protected int  middle_y;

	//文字の一画目の角のy座標
	protected int  horn_y;

	// 右側の辺（画像の各行の最も左側にあるドットのＸ座標、行にひとつもドットがなければ -1）
	protected int  right_x[];

	// 最後に特徴量計算を行った画像（描画用）
	protected BufferedImage  last_image;


	// 特徴量の名前を返す
	public String  getFeatureName()
	{
		return  "一画目の角の傾き";
	}

	// 文字画像から１次元の特徴量を計算する
	public float  evaluate( BufferedImage image )
	{
		int  height = image.getHeight();
		int  width = image.getWidth();

		// 右側の辺を取り出す（各行の最も右側のドットのＸ座標を調べる）
			right_x = new int[ height ];
			for ( int y=0; y<height; y++ )
			{
				// 最初は行に黒ピクセルが１つもないものとして -1 で初期化
				right_x[ y ] = -1;

				// 左側から順番にピクセルを走査
				for ( int x=width-1; x>0; x-- )
				{
					// ピクセルの色を取得
					int  color = image.getRGB( x, y );

					// ピクセルの色が黒であれば最も右側のドットとして座標を記録
					if ( color == 0xff000000 )
					{
						right_x[ y ] = x;
						break;
					}
				}
			}

		//仮の角のy座標
		int new_horn = 0;

		//角の探索に用いる値
		int horn_num = 0;

		//画像の例外処理に用いる値
		int irregular = 0;

		boolean u_switch = false;
		boolean l_switch = false;
		for ( int y=1; y<height-1; y++ )
		{

			//特異画像処理の円滑化
			if(right_x[y-1]==-1 && right_x[y]!=-1 && right_x[y+1]==-1)
			{
				right_x[y]=-1;
			}

			if(right_x[y-1]!=-1 && right_x[y]==-1 && right_x[y+1]!=-1)
			{
				right_x[y]=right_x[y-1];
			}
				if( right_x[y-1] == -1 && right_x[y] != -1 && u_switch==false)
				{
					upper_y = y;
					u_switch = true;
				}

				else if(right_x[y-1] != -1 && right_x[y] == -1 && l_switch==false)
				{
					lower_y = y;
					l_switch = true;
				}


		}

		middle_y = ((lower_y-upper_y)/3)+upper_y+1;
		if( upper_y>160 )
			irregular = 180;

		for ( int y=0; y<middle_y; y++ )
		{
			if(right_x[y]!=-1 && horn_num<right_x[y]-y+irregular)
				new_horn = y;
				horn_num = right_x[y]-y+irregular;
		}

		horn_y = new_horn;

		// 一画目の傾きを求める
		float first_tin;
			first_tin = Math.abs(((float)(right_x[middle_y])-(float)(right_x[horn_y]))/(float)(middle_y-horn_y));

			// 画像を記録（描画用）

		last_image = image;

		return  first_tin;
	}


	// 最後に行った特徴量計算の結果を描画する
	public void  paintImageFeature( Graphics g )
	{
		if ( last_image == null )
			return;

		int  ox = 0, oy = 0;
		g.drawImage( last_image, ox, oy, null );



		int  x0, y0, x1, y1;
		for ( int y=0; y<right_x.length-1; y++ )
		{
			y0 = y;
			y1 = y+1;
			x0 = right_x[ y0 ];
			x1 = right_x[ y1 ];
			if ( ( x0 != -1 ) && ( x1 != -1 ) )
			{

				g.setColor(Color.PINK);
				g.drawLine(right_x[horn_y]-10, horn_y, right_x[horn_y]+10, horn_y);
				g.drawLine(right_x[horn_y], horn_y-10, right_x[horn_y], horn_y+10);

				g.setColor( Color.GREEN);
				g.drawLine(0, middle_y, 255, middle_y);

				g.setColor( Color.YELLOW);
				g.drawLine(right_x[horn_y], horn_y, right_x[middle_y], middle_y);
			}
		}

		String  message;
		g.setColor( Color.RED );
		message = "角のx座標,y座標：  " + right_x[horn_y]+","+horn_y;
		g.drawString( message, ox, oy + 16 );
		message = "文字の中心のx座標,y座標: " +right_x[middle_y]+","+middle_y;
		g.drawString( message, ox, oy + 32 );
		message = "特徴量(傾きの逆数): " + Math.abs(((float)(right_x[middle_y])-(float)(right_x[horn_y]))/(float)(middle_y-horn_y));
		g.drawString( message, ox, oy + 48 );
	}
}
