import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

 //
 // 文字画像の下辺の傾きを特徴量として計算するクラス
//
class FeatureSecondTit implements FeatureEvaluater
	{
	// 文字の高さ
	protected float char_height;

	// 下辺の始点と終点のx座標とy座標
	protected int startX = 0;
	protected int startY = 0;
	protected int endX = 0;
	protected int endY = 0;
	
	//
	protected int topX;
	protected int topY;

	// 下側の辺（画像の各列の最も下側にあるドットのy座標、列にひとつもドットがなければ -1）
	protected int under_y[];
	// 左側の辺（画像の各行の最も左側にあるドットのＸ座標、行にひとつもドットがなければ -1）
	protected int left_x[];

	// 最後に特徴量計算を行った画像（描画用）
	protected BufferedImage last_image;

	// 特徴量の名前を返す
	public String getFeatureName()
	{
		return "下辺の傾き";
	}

	// 文字画像から１次元の特徴量を計算する
	public float evaluate( BufferedImage image )
	{
		int height = image.getHeight();
		int width = image.getWidth();

		// 左側の辺を取り出す（各行の最も左側のドットのＸ座標を調べる）
		left_x = new int[ height ];
		for ( int y=0; y<height; y++ )
		{
			// 最初は行に黒ピクセルが１つもないものとして -1 で初期化
			left_x[ y ] = -1;

			// 左側から順番にピクセルを走査
			for ( int x=0; x<width; x++ )
			{
				// ピクセルの色を取得
				int color = image.getRGB( x, y );

				// ピクセルの色が黒であれば最も左側のドットとして座標を記録
				if ( color == 0xff000000 )
				{
					left_x[ y ] = x;
					break;
				}
			}
		}

		// 文字の高さを計算
		char_height = 0.0f;
		topX = 0;
		topY = 0;
		for ( int y=0; y<height; y++)
		{
			if( left_x[y] != -1 )
			{
				if( char_height == 0.0f)
				{
					topX = left_x[y];
					topY = y;
				}
				char_height++;
			}
		}

		// 下側の辺を取り出す（各列の最も下側のドットのＸ座標を調べる）
		under_y = new int[ width ];
		for ( int x=0; x<width; x++ )
		{
			// 最初は列に黒ピクセルが１つもないものとして -1 で初期化
			under_y[ x ] = -1;

			// 下側から順番にピクセルを走査
			for ( int y=height-1; y>0; y-- )
			{
				// ピクセルの色を取得
				int color = image.getRGB( x, y );

				// ピクセルの色が黒であれば最も左側のドットとして座標を記録
				if ( color == 0xff000000 )
				{
					under_y[ x ] = y;
					break;
				}
			}
		}

		// 下辺の始点の座標の取得
		for ( int x=0; x<width; x++)
		{
			if( under_y[x] != -1 )
			{
				if(x!=width-1 && under_y[x+1]!=-1 && under_y[x]>(topY+(char_height/2)))
				{
					startX = x;
					startY = under_y[x];
					break;
				}
			}
		}

		// 下辺の終点の座標の取得
		for ( int x=width-1; x>0; x--)
		{
			if( under_y[x] != -1 )
			{
				if(x!=width-1 && under_y[x+1]!=-1 && under_y[x]>(topY+((char_height/3)*2)))
				{
					endX = x;
					endY = under_y[x];
					break;
				}
			}
		}

		// 下辺の傾きを計算
		float under_a = 0.0f;
		if ((endY - startY) != 0)
		{
			under_a = (float)((float)(endY - startY) / (float)(endX - startX));
		}

		// 画像を記録（描画用）
		last_image = image;

		return under_a;
	}


	// 最後に行った特徴量計算の結果を描画する
	public void paintImageFeature( Graphics g )
	{
		if ( last_image == null )
			return;

		int ox = 0, oy = 0;
		g.drawImage( last_image, ox, oy, null );


		int x0, y0, x1, y1;
		for ( int x=0; x<under_y.length-1; x++)
		{
			x0 = x;
			x1 = x+1;
			y0 = under_y[ x0 ];
			y1 = under_y[ x1 ];
			if ( ( y0 != -1 ) && ( y1 != -1 ) )
			{
				
				// 下辺の始点と終点を結ぶ線分を描画
				g.setColor( Color.YELLOW );
				g.drawLine( ox + startX, oy + startY, ox + endX, oy + endY );
				
				g.setColor( Color.RED );
				g.drawLine(startX-10, startY, startX+10, startY);
				g.drawLine(startX, startY-10, startX, startY+10);
				
				g.setColor( Color.RED );
				g.drawLine(endX-10, endY, endX+10, endY);
				g.drawLine(endX, endY-10, endX, endY+10);
			}
		}

		String message;
		g.setColor( Color.RED );
		message = "下辺の始点: (" + startX + ", " + startY + ")";
		g.drawString( message, ox, oy + 16 );
		message = "下辺の終点: (" + endX + ", " + endY + ")";
		g.drawString( message, ox, oy + 32 );
		message = "特徴量(下辺の傾き): " + (float)((float)(endY - startY) / (float)(endX - startX));
		g.drawString( message, ox, oy + 48 );
	}
 }
