﻿import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

//
// 文字画像の上辺の長さと文字の横幅の比を特徴量として計算するクラス
//
class FeatureUpperLineLengthWidthRatio implements FeatureEvaluater
	{
	// 上辺の長さと文字の横幅
	protected float top_length;
	protected float char_width;
	// 文字の高さ
	protected float char_height;

	// 上側の辺（画像の各列の最も上側にあるドットのy座標、列にひとつもドットがなければ -1）
	protected int top_y[];
	// 左側の辺（画像の各行の最も左側にあるドットのＸ座標、行にひとつもドットがなければ -1）
	protected int left_x[];

	protected int topX;
	protected int writeX;
	// 最後に特徴量計算を行った画像（描画用）
	protected BufferedImage last_image;


	// 特徴量の名前を返す
	public String getFeatureName()
	{
		return "上辺の長さと文字の横幅の比（上辺の長さ/文字の横幅）";
	}


	// 文字画像から１次元の特徴量を計算する
	public float evaluate( BufferedImage image )
	{
		int height = image.getHeight();
		int width = image.getWidth();

		// 左側の辺を取り出す（各行の最も左側のドットのＸ座標を調べる）
		left_x = new int[ height ];
		for ( int y=0; y<height; y++ )
		{
			// 最初は行に黒ピクセルが１つもないものとして -1 で初期化
			left_x[ y ] = -1;

			// 左側から順番にピクセルを走査
			for ( int x=0; x<width; x++ )
			{
				// ピクセルの色を取得
				int color = image.getRGB( x, y );

				// ピクセルの色が黒であれば最も左側のドットとして座標を記録
				if ( color == 0xff000000 )
				{
					left_x[ y ] = x;
					break;
				}
			}
		}

		// 文字の高さを計算
		char_height = 0.0f;
		topX = 0;
		for ( int y=0; y<height; y++)
		{
			if( left_x[y] != -1 )
			{
				if( char_height == 0.0f)
				{
					topX = left_x[y];
				}
				char_height++;
			}
		}

		// 上側の辺を取り出す（各列の最も上側のドットのＸ座標を調べる）
		top_y = new int[ width ];
		for ( int x=0; x<width; x++ )
		{
			// 最初は列に黒ピクセルが１つもないものとして -1 で初期化
			top_y[ x ] = -1;

			// 上側から順番にピクセルを走査
			for ( int y=0; y<height; y++ )
			{
				// ピクセルの色を取得
				int color = image.getRGB( x, y );

				// ピクセルの色が黒であれば最も左側のドットとして座標を記録
				if ( color == 0xff000000 )
				{
					top_y[ x ] = y;
					break;
				}
			}
		}

		// 文字の横幅を計算
		char_width = 0.0f;
		top_length = 0.0f;
		boolean flag = false;
		for ( int x=0; x<width; x++)
		{

			if( top_y[x] != -1 )
			{
				char_width++;
				if(flag==false)
					writeX=x;
					flag=true;

				if(x!=width-1 && top_y[x+1]!=-1 && Math.abs(top_y[x+1]-top_y[x])<10 && top_y[x]<top_y[topX]+(char_height/2))
				{
					top_length += Math.sqrt((top_y[x+1]-top_y[x])*(top_y[x+1]-top_y[x])+1);
				}
			}
		}

		// 文字の横幅 / 上側の辺の長さ の比を計算
		float top_linearity;
		top_linearity = top_length / char_width;

		// 画像を記録（描画用）
		last_image = image;

		return top_linearity;
	}


	// 最後に行った特徴量計算の結果を描画する
	public void paintImageFeature( Graphics g )
	{
		if ( last_image == null )
			return;

		int ox = 0, oy = 0;
		g.drawImage( last_image, ox, oy, null );



		int x0, y0, x1, y1;
		for ( int x=0; x<top_y.length-1; x++)
		{
			x0 = x;
			x1 = x+1;
			y0 = top_y[ x0 ];
			y1 = top_y[ x1 ];
			if ( ( y0 != -1 ) && ( y1 != -1 ) )
			{
				// 上側の辺のピクセルを描画
				if(y0<top_y[topX]+(char_height/2) && y1<top_y[topX]+(char_height/2))
				{
				g.setColor( Color.RED );
				g.drawLine( ox + x0, oy + y0, ox + x1, oy + y1 );
				}

				g.setColor( Color.GREEN);
				g.drawLine(writeX, 0, writeX, 255);
				g.drawLine(writeX+(int)char_width, 0, writeX+(int)char_width, 255);
			}
		}
		String message;
		g.setColor( Color.RED );
		message = "上辺の長さ: " + top_length;
		g.drawString( message, ox, oy + 16 );
		message = "文字の横幅: " + char_width;
		g.drawString( message, ox, oy + 32 );
		message = "特徴量(文字の幅 / 上辺の長さ): " + top_length / char_width;
		g.drawString( message, ox, oy + 48 );
	}
 }
